GenericAgent Admin Go

启动：运行 ga-admin.exe（Windows）或 ./ga-admin（macOS）。
说明：发布包已包含 cmd/chat_worker.py；GA 服务仍依赖本机 GenericAgent/Python 环境。
