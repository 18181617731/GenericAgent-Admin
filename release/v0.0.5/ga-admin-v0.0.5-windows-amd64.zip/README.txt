GenericAgent Admin Go v0.0.5

Run ga-admin.exe to start the admin UI.
The executable embeds the React/Vite web UI.
GenericAgent services still require your local GenericAgent Python environment.
